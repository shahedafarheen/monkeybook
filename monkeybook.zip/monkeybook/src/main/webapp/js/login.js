$(document).ready(function(){

"use strict";


$.validator.setDefaults({
highlight:function(element){
$(element)
.closest('.form-group')
.addClass('has error')
},


unhighlight:function(element){
$(element)
.closest('.form-group')
.removeClass('has error')
}
});


$('form[id="form1"]').validate({

rules:{
	email: "required",
	psw:{
	required: true
	
}
},
messages:{
	email: "Please enter the Name",
	psw:{
	required: "Please type the password",
	minlength:"type atleast 6 characters"
}
},

submitHandler:function(form){
form.submit();
}

});


// Get the modal



function check(form){
if(form.uname.value=="admin" && form.psw.value=="admin"){
window.open("admin.html","_self")
}
else{
alert("Wrong Entry");
}
}


var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
 

    if (event.target == modal) {
        modal.style.display = "none";	
    }
 
}
				


});