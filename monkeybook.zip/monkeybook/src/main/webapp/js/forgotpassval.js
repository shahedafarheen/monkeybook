//form3 validation

$(document).ready(function(){
	$.validator.setDefaults({
highlight:function(element){
$(element)
.closest('.form-group')
.addClass('has error')
},


unhighlight:function(element){
$(element)
.closest('.form-group')
.removeClass('has error')
}
});
	//form3 validation

$('form[id="form3"]').validate({

rules:{
	email: "required",
	choice:"required",
	text:"required"
},
messages:{
	email: "Please enter the Name",
	choice:"Please provide your choice",
	text:"Please provide your security answer"
},

submitHandler:function(form){
form.submit();
}

});

});


  
// $("button").click(function(){
//    $("form3").html("An Email has been Sent to your mail Id. Please Verify!");
  //});


