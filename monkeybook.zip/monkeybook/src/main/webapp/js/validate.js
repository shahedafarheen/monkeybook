$(document).ready(function(){

"use strict";

$.validator.setDefaults({
highlight: function(element){
$(element)
.closest('.form-group')
.addClass('has error')
},
unhighlight: function(element){
$(element)
.closest('.form-group')
.removeClass('has error')
}

});


$('form[id="form2"]').validate({

rules:{
	uname: "required",
	psw1:{
	required: true,
	minlength: 6
},
	psw2:{
	minlength: 6,
	equalTo : "#psw1"
},
	email:{
	email:true,
	required: true
}
	
},
messages:{
	uname: "Please enter the Name",
	psw1:{
	required: "Please type the password",
	minlength:"type atleast 6 characters"
},
	psw2:{
	equalTo:"Password Mismatch"
},

	email:{
	email: "please enter a valid one",
	required: "this is mandatory"
}
	
},

submitHandler:function(form){
form.submit();
}

});



// Get the modal
var modal =  document.getElementById('id02');


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {


   if (event.target == modal) {
        modal.style.display = "none";
    }

}



});	

