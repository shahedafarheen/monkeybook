$(document).ready(function(){
$('.btn').on("click",function(){
$('label[id="uname-error"]').remove();
$('label[id="psw1-error"]').remove();
$('label[id="psw2-error"]').remove();
$('label[id="emailAddress-error"]').remove();
$("form div").removeClass("error");

$("form")[1].reset();

});

});