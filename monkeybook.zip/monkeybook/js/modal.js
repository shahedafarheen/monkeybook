$(document).ready(function(){
$(".btn").on("click",function(){
 $("form")[0].reset();
 $('label[id="email-error"]').remove();
$('label[id="psw-error"]').remove();

  $("form div").removeClass("error");

 
});


});